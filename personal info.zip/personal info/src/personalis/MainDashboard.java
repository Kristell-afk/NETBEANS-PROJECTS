package personalis;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.util.List;

public class MainDashboard extends JFrame {
    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField searchField, nameField, bdayField, addressField, contactField, emailField;

    // High-End Catchy Color Palette (Updated with Vibrant Blue for Search)
    private final Color COLOR_HEADER_BG = new Color(30, 41, 59);     // Deep Slate
    private final Color COLOR_PRIMARY_BLUE = new Color(37, 99, 235); // Vibrant Royal Blue (Search)
    private final Color COLOR_ACCENT = new Color(16, 185, 129);     // Emerald Success
    private final Color COLOR_DANGER = new Color(225, 29, 72);      // Rose Red
    private final Color COLOR_BG = new Color(241, 245, 249);         // Soft Ice Background
    private final Color COLOR_CARD_BG = Color.WHITE;
    private final Color COLOR_TEXT_MAIN = new Color(15, 23, 42);

    public MainDashboard() {
        setTitle("PERSONALIS - Personal Information System");
        setSize(1100, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Root Container with Padding
        JPanel mainContainer = new JPanel(new BorderLayout(15, 15));
        mainContainer.setBackground(COLOR_BG);
        mainContainer.setBorder(new EmptyBorder(20, 25, 20, 25));

        // 1. Header / Top Panel
        JPanel topPanel = createHeaderPanel();
        
        // 2. Center Content (Table & Search Tools)
        JPanel centerPanel = createTablePanel();

        // 3. Right Sidebar (Add Record Form Card)
        JPanel rightPanel = createFormPanel();

        // Assemble Layout
        mainContainer.add(topPanel, BorderLayout.NORTH);
        mainContainer.add(centerPanel, BorderLayout.CENTER);
        mainContainer.add(rightPanel, BorderLayout.EAST);

        add(mainContainer);

        // Load initial data
        loadTableData();
    }

    private JPanel createHeaderPanel() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(COLOR_HEADER_BG);
        header.setBorder(new EmptyBorder(18, 24, 18, 24));

        JLabel titleLabel = new JLabel("PERSONALIS");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);

        JLabel subtitleLabel = new JLabel("Personal Information System  •  Secure Local Storage");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subtitleLabel.setForeground(new Color(148, 163, 184));

        JPanel textGroup = new JPanel(new GridLayout(2, 1, 0, 4));
        textGroup.setOpaque(false);
        textGroup.add(titleLabel);
        textGroup.add(subtitleLabel);

        header.add(textGroup, BorderLayout.WEST);
        return header;
    }

    private JPanel createTablePanel() {
        JPanel container = new JPanel(new BorderLayout(10, 10));
        container.setOpaque(false);

        // Top Controls: Search Bar & Actions
        JPanel searchBarPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        searchBarPanel.setOpaque(false);
        searchBarPanel.setBorder(new EmptyBorder(0, 0, 5, 0));

        searchField = new JTextField(16);
        searchField.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        searchField.setPreferredSize(new Dimension(210, 36));

        JButton searchButton = createStyledButton("Search", COLOR_PRIMARY_BLUE);
        JButton refreshButton = createStyledButton("Refresh", new Color(71, 85, 105));
        JButton deleteButton = createStyledButton("Delete Selected", COLOR_DANGER);

        JLabel searchLabel = new JLabel("Filter Name:");
        searchLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        searchLabel.setForeground(new Color(51, 65, 85));

        searchBarPanel.add(searchLabel);
        searchBarPanel.add(searchField);
        searchBarPanel.add(searchButton);
        searchBarPanel.add(refreshButton);
        searchBarPanel.add(Box.createHorizontalStrut(15));
        searchBarPanel.add(deleteButton);

        // Custom Styled JTable
        tableModel = new DefaultTableModel(new String[]{"ID", "Full Name", "Birthdate", "Address", "Contact Number", "Email Address"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(tableModel);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(32);
        table.setShowGrid(true);
        table.setGridColor(new Color(226, 232, 240));
        table.setSelectionBackground(new Color(224, 231, 255));
        table.setSelectionForeground(new Color(30, 27, 75));

        // Custom Header Design
        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 13));
        header.setBackground(COLOR_HEADER_BG);
        header.setForeground(Color.WHITE);
        header.setPreferredSize(new Dimension(0, 38));

        // Alternating row colors for clean readability
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (isSelected) {
                    c.setBackground(new Color(224, 231, 255));
                    c.setForeground(COLOR_TEXT_MAIN);
                } else {
                    c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(248, 250, 252));
                    c.setForeground(COLOR_TEXT_MAIN);
                }
                setBorder(noFocusBorder);
                return c;
            }
        });

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.getViewport().setBackground(Color.WHITE);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(203, 213, 225), 1));

        container.add(searchBarPanel, BorderLayout.NORTH);
        container.add(scrollPane, BorderLayout.CENTER);

        // Event Listeners
        refreshButton.addActionListener(e -> loadTableData());
        
        searchButton.addActionListener(e -> {
            String keyword = searchField.getText().trim().toLowerCase();
            tableModel.setRowCount(0);
            List<String[]> records = DBConnection.getAllRecords();
            for (String[] r : records) {
                if (r[1].toLowerCase().contains(keyword)) {
                    tableModel.addRow(r);
                }
            }
        });

        deleteButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow >= 0) {
                String id = tableModel.getValueAt(selectedRow, 0).toString();
                DBConnection.deleteRecord(id);
                JOptionPane.showMessageDialog(this, "Record successfully deleted!");
                loadTableData();
            } else {
                JOptionPane.showMessageDialog(this, "Please select a record from the table first to delete.");
            }
        });

        return container;
    }

    private JPanel createFormPanel() {
        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(COLOR_CARD_BG);
        card.setPreferredSize(new Dimension(280, 0));
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(203, 213, 225), 1),
                new EmptyBorder(18, 18, 18, 18)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 2, 5, 2);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;

        // Inalis na ang emoji dito para walang lumitaw na box
        JLabel title = new JLabel("Add New Record");
        title.setFont(new Font("Segoe UI", Font.BOLD, 15));
        title.setForeground(COLOR_HEADER_BG);
        card.add(title, gbc);

        gbc.gridwidth = 1;
        nameField = addFormField(card, "Full Name:", gbc, 1);
        bdayField = addFormField(card, "Birthdate (YYYY-MM-DD):", gbc, 3);
        addressField = addFormField(card, "Address:", gbc, 5);
        contactField = addFormField(card, "Contact Number:", gbc, 7);
        emailField = addFormField(card, "Email Address:", gbc, 9);

        gbc.gridx = 0; gbc.gridy = 11; gbc.gridwidth = 2;
        gbc.insets = new Insets(18, 2, 4, 2);

        JButton addButton = createStyledButton("Save Information", COLOR_ACCENT);
        addButton.setPreferredSize(new Dimension(240, 40));
        card.add(addButton, gbc);

        addButton.addActionListener(e -> {
            String id = String.valueOf(System.currentTimeMillis() % 10000);
            String name = nameField.getText().trim();
            String bday = bdayField.getText().trim();
            String addr = addressField.getText().trim();
            String cont = contactField.getText().trim();
            String em = emailField.getText().trim();

            if (name.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Full Name is required!");
                return;
            }

            DBConnection.addRecord(id, name, bday, addr, cont, em);
            JOptionPane.showMessageDialog(this, "Record saved successfully!");
            loadTableData();

            // Clear Input Fields
            nameField.setText(""); bdayField.setText(""); addressField.setText(""); contactField.setText(""); emailField.setText("");
        });

        return card;
    }

    private JTextField addFormField(JPanel panel, String labelText, GridBagConstraints gbc, int row) {
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Segoe UI", Font.BOLD, 12));
        label.setForeground(new Color(71, 85, 105));
        panel.add(label, gbc);

        gbc.gridy = row + 1;
        JTextField textField = new JTextField(15);
        textField.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        textField.setPreferredSize(new Dimension(240, 32));
        panel.add(textField, gbc);

        return textField;
    }

    private JButton createStyledButton(String text, Color bg) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorder(new EmptyBorder(8, 16, 8, 16));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private void loadTableData() {
        tableModel.setRowCount(0);
        List<String[]> records = DBConnection.getAllRecords();
        for (String[] r : records) {
            tableModel.addRow(r);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainDashboard().setVisible(true));
    }
}