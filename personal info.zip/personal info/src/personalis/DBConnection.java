package personalis;

import java.io.*;
import java.util.*;

public class DBConnection {
    private static final String FILE_NAME = "personal_records.txt";

    public static void initializeFile() {
        File file = new File(FILE_NAME);
        try {
            if (!file.exists()) {
                file.createNewFile();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<String[]> getAllRecords() {
        initializeFile();
        List<String[]> records = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length >= 6) {
                    records.add(parts);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return records;
    }

    public static void addRecord(String id, String fullName, String birthdate, String address, String contact, String email) {
        initializeFile();
        List<String[]> records = getAllRecords();
        records.add(new String[]{id, fullName, birthdate, address, contact, email});
        saveAllRecords(records);
    }

    public static void deleteRecord(String id) {
        List<String[]> records = getAllRecords();
        records.removeIf(r -> r[0].equals(id));
        saveAllRecords(records);
    }

    private static void saveAllRecords(List<String[]> records) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(FILE_NAME))) {
            for (String[] r : records) {
                pw.println(String.join("|", r));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}